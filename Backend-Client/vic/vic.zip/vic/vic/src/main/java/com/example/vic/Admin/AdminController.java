/*package com.example.vic.Admin;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class AdminController {

    @CrossOrigin
    @GetMapping("/admin")
    public RedirectView admin() {
        // Perform your admin authentication logic here
        // If the admin is authenticated, redirect to the external dashboard project URL
        return new RedirectView("http://127.0.0.1:5500/dashboard%20files/pensions.html");
    }

    @CrossOrigin
    @GetMapping("/user/page")
    public RedirectView page() {
        // Perform your admin authentication logic here
        // If the admin is authenticated, redirect to the external dashboard project URL
        return new RedirectView("http://127.0.0.1:5500/reservationtest2.html");
    }


}*/

