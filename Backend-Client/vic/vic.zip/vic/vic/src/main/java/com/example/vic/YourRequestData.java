package com.example.vic;

public class YourRequestData {

    private int wnb_adl;
    private int wnb_enf;
    private int wnb_beb;
    private String wdate_arr;
    private String wdate_dep;

    public int getWnb_adl() {
        return wnb_adl;
    }

    public void setWnb_adl(int wnb_adl) {
        this.wnb_adl = wnb_adl;
    }

    public int getWnb_enf() {
        return wnb_enf;
    }

    public void setWnb_enf(int wnb_enf) {
        this.wnb_enf = wnb_enf;
    }

    public int getWnb_beb() {
        return wnb_beb;
    }

    public void setWnb_beb(int wnb_beb) {
        this.wnb_beb = wnb_beb;
    }

    public String getWdate_arr() {
        return wdate_arr;
    }

    public void setWdate_arr(String wdate_arr) {
        this.wdate_arr = wdate_arr;
    }

    public String getWdate_dep() {
        return wdate_dep;
    }

    public void setWdate_dep(String wdate_dep) {
        this.wdate_dep = wdate_dep;
    }
    }







