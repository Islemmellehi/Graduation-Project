/*
package com.example.vic.Config;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.sql.SQLOutput;

public class PasswordGenerator {
    public static void  main(String[] args){
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String rawPassword1 ="shayma";
        String rawPassword ="1234";
        String encodePassword = encoder.encode(rawPassword);
        String encodePassword1 = encoder.encode(rawPassword1);
        System.out.println(encodePassword );
        System.out.println(encodePassword1 );

    }

}*/