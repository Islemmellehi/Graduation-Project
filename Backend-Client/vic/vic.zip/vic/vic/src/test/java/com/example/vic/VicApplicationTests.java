package com.example.vic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VicApplicationTests {

	@Test
	void contextLoads() {
	}

}
